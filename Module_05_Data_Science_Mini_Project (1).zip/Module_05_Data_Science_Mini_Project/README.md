# Module 05 – Data Science Mini Project

## Project
Wine Quality Exploratory Data Analysis using Python.

## Objective
- Select and load a real-world public dataset.
- Inspect and clean the data.
- Explore distributions and relationships.
- Create visualizations.
- Generate meaningful, data-driven insights.

## Dataset source
UCI Machine Learning Repository – Wine Quality:
https://archive.ics.uci.edu/dataset/186/wine+quality

The notebook downloads the red wine CSV from the official UCI dataset ZIP when executed. An internet connection is required for the initial download.

## Files
- `Module_05_Data_Science_Mini_Project.ipynb` – Main Google Colab/Jupyter notebook.
- `Module_05_Data_Science_Mini_Project.py` – Python source script.
- `requirements.txt` – Required Python libraries.
- `README.md` – Project instructions.

## Run in Google Colab
1. Open https://colab.research.google.com/
2. Choose File → Upload notebook.
3. Upload `Module_05_Data_Science_Mini_Project.ipynb`.
4. Run all cells from top to bottom.
5. Review the charts and printed insights.
6. Save the notebook to your Google Drive.
7. Click Share → General access → Anyone with the link → Viewer.
8. Copy the notebook link for your submission.

## Run locally
Install dependencies:
`pip install -r requirements.txt`

Run:
`python Module_05_Data_Science_Mini_Project.py`

## Notes
- The analysis uses the red wine dataset.
- Duplicate rows are removed before analysis.
- Correlation indicates association, not causation.
- This is an exploratory data analysis project, not a wine-quality prediction model.
