"""Module 05 – Data Science Mini Project: Wine Quality EDA."""
# Run in Google Colab or a Python environment with internet access.

# 1. Import required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from IPython.display import display
from urllib.request import urlopen
from zipfile import ZipFile
from io import BytesIO

sns.set_theme(style="whitegrid")
plt.rcParams["figure.figsize"] = (9, 5)

print("Libraries imported successfully!")

# 2. Download and load the real-world UCI Wine Quality dataset
dataset_url = "https://archive.ics.uci.edu/static/public/186/wine+quality.zip"

with urlopen(dataset_url) as response:
    zip_bytes = response.read()

with ZipFile(BytesIO(zip_bytes)) as z:
    csv_name = "winequality-red.csv"
    with z.open(csv_name) as file:
        df = pd.read_csv(file, sep=";")

print("Dataset loaded successfully!")
print("Dataset shape:", df.shape)
display(df.head())

# 3. Understand the dataset
print("Column names:")
print(df.columns.tolist())

print("\nDataset information:")
df.info()

print("\nStatistical summary:")
display(df.describe().round(2))

print("\nMissing values in each column:")
display(df.isnull().sum())

# 4. Data quality checks and preparation
print("Duplicate rows:", df.duplicated().sum())

# Remove duplicate rows, if any
df = df.drop_duplicates().copy()

print("Shape after removing duplicates:", df.shape)
print("Missing values after cleaning:", df.isnull().sum().sum())

# 5. Distribution of wine quality scores
plt.figure(figsize=(8, 5))
sns.countplot(data=df, x="quality")
plt.title("Distribution of Wine Quality Scores")
plt.xlabel("Quality score")
plt.ylabel("Number of wine samples")
plt.tight_layout()
plt.show()

# 6. Distribution of alcohol content
plt.figure(figsize=(8, 5))
sns.histplot(data=df, x="alcohol", bins=20, kde=True)
plt.title("Distribution of Alcohol Content")
plt.xlabel("Alcohol (%)")
plt.ylabel("Number of samples")
plt.tight_layout()
plt.show()

# 7. Correlation heatmap
plt.figure(figsize=(12, 8))
correlation = df.corr(numeric_only=True)
sns.heatmap(correlation, annot=True, fmt=".2f", cmap="coolwarm", center=0)
plt.title("Correlation Between Wine Features")
plt.tight_layout()
plt.show()

# 8. Alcohol content vs wine quality
plt.figure(figsize=(9, 5))
sns.boxplot(data=df, x="quality", y="alcohol")
plt.title("Alcohol Content Across Wine Quality Scores")
plt.xlabel("Quality score")
plt.ylabel("Alcohol (%)")
plt.tight_layout()
plt.show()

# 9. Volatile acidity vs wine quality
plt.figure(figsize=(9, 5))
sns.boxplot(data=df, x="quality", y="volatile acidity")
plt.title("Volatile Acidity Across Wine Quality Scores")
plt.xlabel("Quality score")
plt.ylabel("Volatile acidity")
plt.tight_layout()
plt.show()

# 10. Fixed acidity vs citric acid
plt.figure(figsize=(9, 5))
sns.scatterplot(data=df, x="fixed acidity", y="citric acid",
                hue="quality", palette="viridis", alpha=0.75)
plt.title("Fixed Acidity vs Citric Acid")
plt.xlabel("Fixed acidity")
plt.ylabel("Citric acid")
plt.tight_layout()
plt.show()

# 11. Compare average feature values by quality score
quality_means = df.groupby("quality")[["alcohol", "volatile acidity",
                                       "citric acid", "sulphates"]].mean()

display(quality_means.round(2))

quality_means.plot(kind="bar", figsize=(11, 6))
plt.title("Average Selected Features by Wine Quality")
plt.xlabel("Quality score")
plt.ylabel("Average feature value")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

# 12. Generate data-driven insights
print("========== KEY DATA INSIGHTS ==========")

print("\n1. Most common wine quality score:",
      int(df["quality"].mode().iloc[0]))

print("\n2. Average wine quality:",
      round(df["quality"].mean(), 2))

print("\n3. Average alcohol content:",
      round(df["alcohol"].mean(), 2), "%")

print("\n4. Average volatile acidity:",
      round(df["volatile acidity"].mean(), 3))

quality_corr = df.corr(numeric_only=True)["quality"].drop("quality")
print("\n5. Features most positively correlated with quality:")
print(quality_corr.sort_values(ascending=False).head(3).round(3))

print("\n6. Features most negatively correlated with quality:")
print(quality_corr.sort_values().head(3).round(3))

print("\n7. Number of records analyzed:", len(df))
print("\n=======================================")

# 13. Save cleaned dataset and analysis summary
df.to_csv("wine_quality_cleaned.csv", index=False)

summary = pd.DataFrame({
    "Metric": ["Number of records", "Average quality",
               "Average alcohol (%)", "Average volatile acidity"],
    "Value": [len(df), round(df["quality"].mean(), 2),
              round(df["alcohol"].mean(), 2),
              round(df["volatile acidity"].mean(), 3)]
})
summary.to_csv("wine_quality_summary.csv", index=False)

print("Saved wine_quality_cleaned.csv")
print("Saved wine_quality_summary.csv")
print("\nPROJECT COMPLETED SUCCESSFULLY!")

